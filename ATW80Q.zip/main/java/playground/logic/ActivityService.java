package playground.logic;

public interface ActivityService {
	public void setElementService(ElementService elementService);

	public void setUserService(UserService userService);

	public String toString();

}
