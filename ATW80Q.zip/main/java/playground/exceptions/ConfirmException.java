package playground.exceptions;

public class ConfirmException extends RuntimeException {

	public ConfirmException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
