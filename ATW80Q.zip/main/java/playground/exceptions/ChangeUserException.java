package playground.exceptions;

public class ChangeUserException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ChangeUserException(String string) {
		super(string);
	}

}
